from flask import Flask,request,render_template_string
app=Flask(__name__)
todos=[]
html="<h2>Flask To-Do App</h2>"
@app.route('/',methods=['GET','POST'])
def home():
    if request.method=='POST': todos.append(request.form['task'])
    return render_template_string(html+str(todos))
app.run()