from django.http import HttpResponse
def home(request): return HttpResponse('Simple Django Notes App Running!')