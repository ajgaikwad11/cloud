require 'sinatra'
get('/'){'Hello from Ruby Sinatra App!'}