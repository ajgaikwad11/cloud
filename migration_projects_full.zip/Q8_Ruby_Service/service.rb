require 'sinatra'
get('/ping'){'pong'}