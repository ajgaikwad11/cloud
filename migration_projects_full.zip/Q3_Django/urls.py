from django.urls import path
from home_views import index
urlpatterns=[path('',index)]