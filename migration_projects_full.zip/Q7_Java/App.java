package com.example;
public class App{public static void main(String[]a){System.out.println("Hello from Java Maven App!");}}